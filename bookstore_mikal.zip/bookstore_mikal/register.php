<?php
include "config/koneksi.php";
if(isset($_POST['register'])){

    $nama = $_POST['nama'];
    $email = $_POST['email'];
    $password = $_POST['password'];
    $alamat = $_POST['alamat'];

    $query = mysqli_query($conn,

    "INSERT INTO users
    (nama,email,password,alamat,role)

    VALUES

    ('$nama',
    '$email',
    '$password',
    '$alamat',
    'user')"


    );

    if($query){

    echo "
    <script>
    alert('Registrasi berhasil');
    window.location='login.php';
    </script>
    ";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>daftar akun bookmart</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    
<div class="register-container">
    <div class="register-card">
        <div class="register-header">

        <h1>
            KAL BOOKSTORE
</h1>
<p>
    buat akun untuk memulai berbelanja buku favorit apache_response_headers</p>
</div>
<form method="POST">
    <div class="input-group">

    <label>
        nama lengkap
</label>

<input 
type="text"
name="nama"
placeholder="masukan nama lengkap"
required>
</div>

<div class="input-group">

<label>
    email </label>
    <input
    type="email"
    name="email"
    placeholder="masukan email"
    required>

</div>
<div class="input-group">
    <label>
        password 
</label>
<input
    type="password"
    name="password"
    placeholder="masukan password"
    required>
</div>

<div class="input-group">
    <label>
        alamat lengkap
</label>
<textarea
    name="alamat"
    placeholder="masukan alamat"
    required>
</textarea>
</div>

<button
class="btn-register"
name="register">
Daftar Sekarang
</button>

<div class="login-link">

sudah punya akun?
<a href="login.php">
    login disini
</a>
</div>
</form>
</div>
</div>
</body>
</html>