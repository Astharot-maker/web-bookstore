<?php
session_start();
include "config/koneksi.php";

$kategori = mysqli_query(
    $conn,
    "SELECT * FROM kategori"
);
?>

<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>BOOKMART</title>
    <link rel="stylesheet" href="css/style.css">
</head>

<body>
    <nav class="navbar">
        <div class="logo">
           📚 KAL BOOKMART
        </div>
        <ul class="nav-menu">
            <li>
                <a href="index.php">Home</a>
            </li>
            <li>
                <a href="katalog.php">Katalog</a>
            </li>

            <?php if (isset($_SESSION['role'])) { ?>
                <?php if ($_SESSION['role'] == "admin") { ?>
                    <li>
                        <a href="admin/index.php">Dashboard</a>
                    </li>
                <?php } else { ?>
                    <li>
                        <a href="user/index.php">Dashboard</a>
                    </li>
                <?php } ?>
                <li>
                    <a href="logout.php">Logout</a>
                </li>
            <?php } else { ?>
                <li>
                    <a href="login.php">Login</a>
                </li>
                <li>
                    <a href="register.php">Register</a>
                </li>
            <?php } ?>
        </ul>
    </nav>

    <section class="hero">
        <h1>Temukan Buku Favoritmu</h1>
        <p>Ribuan buku tersedia untuk kebutuhan belajar dan membaca</p>
        <a href="katalog.php" class="btn">Lihat Katalog</a>
    </section>

    <div class="content-user">
        <h1 style="text-align:center">Kategori Buku</h1>
        <div class="category-container">
            <?php while ($row = mysqli_fetch_assoc($kategori)) { ?>
                <div class="category-card">
                    <h2><?= $row['nama_kategori']; ?></h2>
                    <p>Temukan berbagai koleksi buku terbaik</p>
                    <a href="katalog.php" class="btn">Lihat Buku</a>
                </div>
            <?php } ?>
        </div>
    </div>

    <footer>
        <p>&copy; 2026 BOOKMART</p>
    </footer>
</body>

</html>