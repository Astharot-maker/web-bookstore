<?php
include "config/koneksi.php";
$data = mysqli_query($conn,
"SELECT buku.*, kategori.nama_kategori
FROM buku
INNER JOIN kategori
ON buku.id_kategori = kategori.id_kategori
ORDER BY id_buku DESC"
);
?>

<!DOCTYPE html>
<html>
<head>
<title>
Katalog Buku
</title>
<link rel="stylesheet" href="css/style.css">
</head>

<body>
<!-- NAVBAR -->
<nav class="navbar">
<div class="logo">
📚 KAL BOOKSTORE
</div>
<ul class="nav-menu">
<li>
<a href="index.php">
Home
</a>
</li>

<li>
<a href="katalog.php">
Katalog
</a>
</li>

<li>
<a href="login.php">
Login
</a>
</li>

<li>
<a href="register.php">
Register
</a>
</li>
</ul>
</nav>

<div class="content-user">
<h1>
Katalog Buku
</h1>
<p>
Temukan berbagai koleksi buku terbaik KAL BOOKSTORE
</p>

<div class="book-container">
<?php while($row=mysqli_fetch_assoc($data)){ ?>
<div class="book-card">
<?php if($row['gambar']!=""){ ?>
<img src="images/buku/<?= $row['gambar']; ?>">
<?php }else{ ?>
<img src="images/no-image.png">
<?php } ?>

<h3>
<?= $row['judul_buku']; ?>
</h3>

<p>
Penulis:
<?= $row['penulis']; ?>
</p>

<p>
Kategori:
<?= $row['nama_kategori']; ?>
</p>

<h4>
Rp <?= number_format($row['harga'],0,',','.'); ?>
</h4>

<a href="login.php" class="btn">
Beli Buku
</a>
</div>
<?php } ?>
</div>
</div>
</body>
</html>