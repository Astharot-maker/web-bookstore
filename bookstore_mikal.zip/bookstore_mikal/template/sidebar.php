<div class="sidebar">

    <div class="sidebar-logo">

        📚 KAL BOOKSTORE

    </div>

    <div class="menu">

        <a href="index.php">

            🏠 Dashboard

        </a>

        <a href="kategori.php">

            📂 Kategori Buku

        </a>

        <a href="buku.php">

            📚 Data Buku

        </a>

        <a href="pesanan.php">

            🛒 Pesanan

        </a>

        <a href="user.php">

            👥 User

        </a>

        <a href="pesan.php">

            📩 Pesan User

        </a>

        <li>

            <a href="pemasukan.php">

                💰 Pemasukan

            </a>

        </li>

        <a href="../logout.php">

            🚪 Logout

        </a>

    </div>

</div>