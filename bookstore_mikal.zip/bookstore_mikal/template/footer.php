footer>

    <center>

        <p>
            © 2026 KAL BOOKSTORE
        </p>

        <p>
            Belanja Buku Mudah dan Cepat
        </p>

    </center>

</footer>