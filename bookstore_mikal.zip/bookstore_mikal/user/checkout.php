<?php

session_start();

include "../config/koneksi.php";


if(!isset($_SESSION['role']) || $_SESSION['role']!="user"){

header("location:../login.php");

exit;

}



// cek keranjang


if(!isset($_SESSION['cart']) || count($_SESSION['cart'])==0){


echo "

<script>

alert('Keranjang masih kosong');

window.location='katalog.php';

</script>

";


exit;


}



$id_user = $_SESSION['id_user'];




// =====================
// PROSES CHECKOUT
// =====================


if(isset($_POST['checkout'])){


$metode_pembayaran = $_POST['metode_pembayaran'];


$tanggal = date('Y-m-d');


$status = "Menunggu Pembayaran";


$status_pembayaran = "Belum Bayar";




// =====================
// HITUNG TOTAL BELANJA
// =====================


$total = 0;


foreach($_SESSION['cart'] as $id_buku){


$data_buku = mysqli_query($conn,


"SELECT harga FROM buku WHERE id_buku='$id_buku'"


);


$buku = mysqli_fetch_assoc($data_buku);


$total += $buku['harga'];


}





// =====================
// SIMPAN PESANAN
// =====================


$query = mysqli_query($conn,


"INSERT INTO pesanan


(

id_user,

tanggal,

total,

status,

metode_pembayaran,

status_pembayaran


)


VALUES


(

'$id_user',

'$tanggal',

'$total',

'$status',

'$metode_pembayaran',

'$status_pembayaran'


)

"

);






if($query){



$id_pesanan = mysqli_insert_id($conn);




// simpan detail pesanan


foreach($_SESSION['cart'] as $id_buku){



mysqli_query($conn,


"INSERT INTO detail_pesanan


(

id_pesanan,

id_buku,

jumlah


)


VALUES


(

'$id_pesanan',

'$id_buku',

'1'


)


"

);



}





unset($_SESSION['cart']);





echo "


<script>


alert('Pesanan berhasil dibuat, silahkan lakukan pembayaran');


window.location='pesanan.php';


</script>


";




}



}



?>
<!DOCTYPE html>

<html>



<head>


<title>

Checkout KAL BOOKSTORE

</title>



<link rel="stylesheet" href="../css/style.css">



</head>



<body>




<?php include "../template/navbar.php"; ?>





<div class="content-user">



<div class="card">





<h1>

Checkout Pesanan

</h1>




<p>

Silahkan pilih metode pembayaran

</p>






<form method="POST">





<label>

Metode Pembayaran

</label>





<select name="metode_pembayaran" required>



<option value="">

-- Pilih Pembayaran --

</option>



<option value="Transfer Bank">

Transfer Bank

</option>



<option value="E-Wallet">

E-Wallet

</option>



<option value="COD">

COD

</option>



</select>







<div class="payment-info">


<h3>
Informasi Pembayaran
</h3>


<hr>


<h4>
Kirim Bukti Pembayaran
</h4>


<p>
Setelah melakukan pembayaran, silahkan kirim bukti transfer melalui WhatsApp Admin.
</p>


<p>
Nomor WhatsApp:
</p>


<h3>
📱 0857-6688-9900
</h3>


<p>
Cantumkan nama pemesan dan nomor pesanan agar transaksi dapat segera diproses.
</p>


<hr>



<h4>

Transfer Bank

</h4>


<p>

Bank BCA

</p>


<p>

No Rekening:

<b>

1234567890

</b>

</p>


<p>

Atas Nama:

<b>

KAL BOOKSTORE Indonesia

</b>

</p>





<hr>





<h4>

E-Wallet

</h4>


<p>

DANA / OVO

</p>


<p>

Nomor:

<b>

081234567890

</b>

</p>





<hr>





<h4>

COD (Cash On Delivery)

</h4>


<p>

Pembayaran dilakukan ketika buku sudah diterima.

</p>





</div>







<br>





<button class="btn" name="checkout">


Konfirmasi Pesanan


</button>






</form>





</div>




</div>






</body>



</html>