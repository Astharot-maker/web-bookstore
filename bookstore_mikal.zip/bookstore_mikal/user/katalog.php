<?php

session_start();

include "../config/koneksi.php";

if (!isset($_SESSION['role']) || $_SESSION['role'] != "user") {

    header("location:../login.php");

    exit;
}

// =======================
// FITUR SEARCH BUKU
// =======================

if (isset($_GET['keyword'])) {

    $keyword = $_GET['keyword'];

    $data = mysqli_query(
        $conn,

        "SELECT buku.*, kategori.nama_kategori

        FROM buku

        INNER JOIN kategori

        ON buku.id_kategori = kategori.id_kategori

        WHERE buku.judul_buku LIKE '%$keyword%'

        ORDER BY id_buku DESC"

    );
} else {

    $data = mysqli_query(
        $conn,

        "SELECT buku.*, kategori.nama_kategori

    FROM buku

    INNER JOIN kategori

    ON buku.id_kategori = kategori.id_kategori

    ORDER BY id_buku DESC"

    );
}

?>

<!DOCTYPE html>

<html>

<head>

    <title>

        Katalog Buku

    </title>

    <link rel="stylesheet" href="../css/style.css">

</head>

<body>

    <?php

    include "../template/navbar.php";

    ?>

    <div class="content-user">

        <h1>

            Katalog Buku

        </h1>

        <p>

            Temukan buku favoritmu

        </p>

        <!-- SEARCH -->

        <div class="search-box">

            <form method="GET">

                <input

                    type="text"

                    name="keyword"

                    placeholder="Cari judul buku..."

                    value="<?= isset($_GET['keyword']) ? $_GET['keyword'] : ''; ?>"
                >
            <button class="btn">

                    Cari

                </button>

            </form>

        </div>

        <div class="book-container">

            <?php

            if (mysqli_num_rows($data) > 0) {

                while ($row = mysqli_fetch_assoc($data)) {

            ?>

                    <div class="book-card">

                        <img

                            src="../images/buku/<?= $row['gambar']; ?>"
                        >
                        <h3>

                            <?= $row['judul_buku']; ?>

                        </h3>

                        <p>

                            <?= $row['penulis']; ?>

                        </p>

                        <p>

                            <?= $row['nama_kategori']; ?>

                        </p>

                        <h4>

                            Rp <?= number_format($row['harga'], 0, ',', '.'); ?>

                        </h4>

                        <a

                            href="detail_buku.php?id=<?= $row['id_buku']; ?>"

                            class="btn"
                        >
                            Detail Buku

                        </a>

                    </div>

            <?php

                }
            } else {

            ?>

                <h3>

                    Buku tidak ditemukan 😢

                </h3>

            <?php

            }

            ?>

        </div>

    </div>

</body>

</html>