<?php


session_start();


include "../config/koneksi.php";



if(!isset($_SESSION['role']) || $_SESSION['role']!="user"){


header("location:../login.php");

exit;


}




// membuat session cart jika belum ada


if(!isset($_SESSION['cart'])){


$_SESSION['cart']=[];

}




// proses tambah buku


if(isset($_GET['id'])){


$id=$_GET['id'];



if(!in_array($id,$_SESSION['cart'])){


$_SESSION['cart'][]=$id;


}



header("location:keranjang.php");

exit;


}




?>
<!DOCTYPE html>

<html>


<head>


<title>

Keranjang Belanja

</title>


<link rel="stylesheet" href="../css/style.css">


</head>


<body>



<?php

include "../template/navbar.php";

?>



<div class="content-user">


<h1>

Keranjang Belanja

</h1>



<table width="100%">


<tr>


<th>

Judul Buku

</th>


<th>

Harga

</th>


<th>

Aksi

</th>


</tr>




<?php



$total=0;



if(count($_SESSION['cart'])>0){



foreach($_SESSION['cart'] as $id){



$data=mysqli_query($conn,


"SELECT * FROM buku

WHERE id_buku='$id'

");


$buku=mysqli_fetch_assoc($data);



$total += $buku['harga'];



?>



<tr>


<td>

<?= $buku['judul_buku']; ?>

</td>



<td>

Rp <?= number_format($buku['harga'],0,',','.'); ?>

</td>



<td>


<a href="hapus_cart.php?id=<?= $id; ?>"

class="action-delete">


Hapus


</a>


</td>



</tr>



<?php

}

}

?>



<tr>


<td>


<b>Total</b>


</td>


<td>


<b>

Rp <?= number_format($total,0,',','.'); ?>

</b>


</td>


</tr>


</table>



<br>


<a href="checkout.php" class="btn">

Checkout

</a>



</div>


</body>

</html>