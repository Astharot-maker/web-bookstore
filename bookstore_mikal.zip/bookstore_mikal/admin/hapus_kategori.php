<?php

session_start();

include "../config/koneksi.php";

if ($_SESSION['role'] != "admin") {
    header("location:../login.php");
    exit;
}

$id = $_GET['id'];

// Cek apakah kategori masih digunakan oleh buku
$cek = mysqli_query(
    $conn,
    "SELECT id_kategori FROM buku WHERE id_kategori='$id'"
);

if (mysqli_num_rows($cek) > 0) {

    echo "
    <script>
        alert('Kategori tidak bisa dihapus karena masih digunakan oleh data buku!');
        window.location='kategori.php';
    </script>
    ";

    exit;
}

// Hapus kategori jika tidak digunakan
$query = mysqli_query(
    $conn,
    "DELETE FROM kategori WHERE id_kategori='$id'"
);

if ($query) {

    echo "
    <script>
        alert('Kategori berhasil dihapus!');
        window.location='kategori.php';
    </script>
    ";

} else {

    echo "
    <script>
        alert('Kategori gagal dihapus!');
        window.location='kategori.php';
    </script>
    ";

}

?>