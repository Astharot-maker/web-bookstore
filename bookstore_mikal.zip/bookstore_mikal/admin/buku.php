<?php

session_start();

include "../config/koneksi.php";

// cek admin

if (!isset($_SESSION['role']) || $_SESSION['role'] != "admin") {

    header("location: ../login.php");
    
    exit;
}

// mengambil data buku + kategori

$data = mysqli_query(
    $conn,

    "SELECT buku.*, kategori.nama_kategori

    FROM buku

    INNER JOIN kategori

    ON buku.id_kategori = kategori.id_kategori

    ORDER BY id_buku DESC"

);

?>

<!DOCTYPE html>

<html>

<head>

    <title>

        Data Buku

    </title>

    <link rel="stylesheet" href="../css/style.css">

</head>

<body>

    <?php

    include "../template/sidebar.php";

    ?>

    <div class="content">

        <h1>

            Data Buku

        </h1>

        <p>

            Kelola seluruh koleksi buku pada KAL BOOKSTORE

        </p>

        <br>

        <a href="tambah_buku.php" class="btn">

            + Tambah Buku

        </a>

        <br><br>

        <table width="100%">

            <tr>

                <th>No</th>

                <th>Gambar</th>

                <th>Judul Buku</th>

                <th>Kategori</th>

                <th>Penulis</th>

                <th>Penerbit</th>

                <th>Harga</th>

                <th>Stok</th>

                <th>Aksi</th>

            </tr>

            <?php

            $no = 1;

            while ($row = mysqli_fetch_assoc($data)) {

            ?>

                <tr>

                    <td>

                        <?= $no++; ?>

                    </td>

                    <td>

                        <img

                            src="../images/buku/<?= $row['gambar']; ?>"

                            class="book-image">

                    </td>

                    <td>

                        <b>

                            <?= $row['judul_buku']; ?>

                        </b>

                    </td>

                    <td>

                        <?= $row['nama_kategori']; ?>

                    </td>

                    <td>

                        <?= $row['penulis']; ?>

                    </td>

                    <td>

                        <?= $row['penerbit']; ?>

                    </td>

                    <td>

                        <span class="price">

                            Rp <?= number_format($row['harga'], 0, ',', '.'); ?>

                        </span>

                    </td>

                    <td>

                        <span class="stock">

                            <?= $row['stok']; ?>

                        </span>

                    </td>

                    <td>

                        <a

                            href="edit_buku.php?id=<?= $row['id_buku']; ?>"

                            class="action-edit">

                            Edit

                        </a>

                        <a

                            href="hapus_buku.php?id=<?= $row['id_buku']; ?>"

                            class="action-delete"

                            onclick="return confirm('Yakin ingin menghapus buku ini?')">

                            Hapus

                        </a>

                    </td>

                </tr>

            <?php

            }

            ?>

        </table>

    </div>

</body>

</html>